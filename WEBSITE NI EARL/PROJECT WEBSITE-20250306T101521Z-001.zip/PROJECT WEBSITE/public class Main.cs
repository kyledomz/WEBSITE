public class Main
{
    if ((age >= 14) && (age <= 19))
    status = "Eligible";
} else {
    status = "Not Eligible";
}

